def process_items(items_t: tuple[int, int, str], items_s: set[bytes]):
    return items_t, items_s
